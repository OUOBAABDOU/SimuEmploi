# SimuEmploi — réétude Burkina Faso / AES

Ce dossier réunit le code de l'archive fournie et la réétude de son cahier des charges. Les choix de marché retenus sont ceux précisés par le porteur : **Burkina Faso d'abord, puis Mali et Niger**, pour le coaching individuel, l'accompagnement par les établissements et l'aide à l'évaluation des candidats.

- [Dossier d'idée et de conception](docs/conception/README.md) : viabilité, problème, technologies, architecture Python retenue, 16 diagrammes et méthode de validation.
- [Backend Python retenu](docs/conception/06_OPTION_BACKEND_PYTHON.md) : FastAPI/Pydantic, PostgreSQL, SQLAlchemy/Alembic, Celery/RabbitMQ avec outbox et migration à réaliser.
- [Étude de recadrage et audit](docs/ETUDE_SIMUEMPLOI_BURKINA_AES.md) : diagnostic vérifié, décisions produit, architecture, cadre local, modèle économique et déploiement.
- [Cahier des charges révisé](docs/CAHIER_DES_CHARGES_REVISE.md) : périmètre, règles d'accès, exigences mesurables et critères de réception.
- [Vérifications techniques](docs/VERIFICATIONS_TECHNIQUES.md) : méthode, résultats et limites de l'audit.
- [Cahier des charges initial](references/CAHIER_DES_CHARGES_INITIAL.txt) : copie du texte fourni, conservé comme référence.
- `projet-source/` : fichiers extraits de l'archive. Le code applicatif n'a pas été corrigé dans cette mission de réétude.
- `outils/diagnostic-source.cjs` : diagnostic reproductible de quelques calculs du prototype.

Le porteur a adopté la stack Python du dossier joint le **20 novembre 2026** ; l'ADR-11 consigne cette décision. La conception est alignée, tandis que la migration applicative et les POC restent à réaliser. Les fonctionnalités et tarifs du texte initial demeurent des éléments à examiner. L'étude distingue les faits constatés, les décisions du porteur et les hypothèses à tester sur le terrain.
