# Responsables, décisions et backlog S0

Référence S0-0.3, 22 novembre 2026. **OUOBA Abdou Rasmané** est l’interlocuteur nommé pour produit, métier et coordination. Les cinq noms ci-dessous sont reçus dans ce chat et affectés dans leur ordre de présentation. Aucune disponibilité n’est encore fournie ; la capacité réelle reste à confirmer.

## Affectation du travail

| Place | Responsabilité complète | Revue / dépendance | Affectation nominative |
|---|---|---|---|
| D1 | Accès, préférences, matrice de droits et demandes de données | D2 ; double revue D5 sur identité/données | Ouoba |
| D2 | Catalogue, plan/questions/grille, session et transitions | D3 ; coordination métier avec OUOBA | Abdou |
| D3 | Évaluation, preuves, budgets, erreurs et résultat tardif | D4 ; grille D2 et exploitation D5 | Rasmané |
| D4 | Parcours, composants, aide, mobile, protocole et observations UX | D5 ; contenu D1–D3 | limata |
| D5 | Architecture, contrats transversaux, environnements et exploitation | D1 ; orchestration avec chaque domaine | Oumou |

L’atelier permet noms ou pseudonymes, jours disponibles sur un sprint de deux semaines et confirmation de compréhension du périmètre. Une personne portant plusieurs rôles ne compte qu’une fois dans la capacité ; aucune affectation ne permet de multiplier ses jours disponibles. La revue doit être indépendante quand possible ; sinon tracer la limite.

## Décisions reçues et propositions techniques

| ID | Décision / proposition | État / responsable |
|---|---|---|
| S0-DEC-01 | Construction neuve, candidat d’abord, Burkina puis AES | Reçu du porteur |
| S0-DEC-02 | Premier emploi/stage en français, coaching privé | Priorité reçue ; notices et périmètre adulte à confirmer avant pilote / OUOBA |
| S0-DEC-03 | React/TypeScript + Python/FastAPI, monolithe modulaire | Stack reçue ; versions du démarrage vérifiées |
| S0-DEC-04 | PostgreSQL/SQLAlchemy/Alembic ; Celery/RabbitMQ + outbox | Architecture reçue ; qualification d’environnement en S1 / D5 |
| S0-DEC-05 | Présentation guidée en référence initiale | Proposition à valider après essais / OUOBA + D4 |
| S0-DEC-06 | Texte non blanc 1–4 000 caractères, sans seuil de compétence par longueur | Proposition de contrat / D2 + D3 |
| S0-DEC-07 | Réponse confirmée immuable ; reprise explicite ; nouveau travail dans nouvel essai | Proposition de simplification initiale / D2 |
| S0-DEC-08 | Pas de score global ; preuves exactes ; pas d’appréciation de personnalité | Référence de coaching à recevoir / OUOBA + D3 |
| S0-DEC-09 | Noms canoniques `sessions` et `privacy` ; `profile` sous-domaine d’`identity` | Clarification de nommage avec l’ADR ; anciens noms simulation/data_rights restent des alias documentaires / D5 |
| S0-DEC-10 | Catalogue public ; ressources privées d’autrui retournent 404 | Proposition cohérente d’anti-divulgation / D1 + D5 |
| S0-DEC-11 | Quotas, enveloppe monétaire et tentatives fournisseur | Valeurs à décider et qualifier avant S4 ; aucune offre illimitée / OUOBA + D3/D5 |
| S0-DEC-12 | Rétention, notices, hébergement et traitement des sauvegardes | Politique à recevoir avant collecte privée/pilote ; ne pas inventer de durée légale / OUOBA + D1/D5 |

Une décision technique préparée n’est pas une approbation produit. Les décisions ouvertes ont un responsable et un point de fermeture avant le lot concerné ; elles ne sont pas déclarées résolues pour fermer S0.

## Comparaison OIDC pour le choix avant S2

Comparaison qualitative de conception, sans tarif, contrat signé ni essai fournisseur. Tout fournisseur doit permettre validation OIDC, révocation, retours autorisés et exploitation compatible avec les besoins du pilote.

| Option | Intérêt | Charge / vérifications requises |
|---|---|---|
| Keycloak hébergé pour le projet | Contrôle de configuration et déploiement OIDC | Exploitation, patchs, sauvegarde/restauration, courrier et disponibilité à assumer ; ne pas héberger sans capacité D5 |
| Service OIDC géré, par exemple Auth0 | Exploitation d’identité en partie externalisée | Contrat, localisation, export, coûts et modes d’accès réels à vérifier avec le fournisseur |
| Fournisseur OIDC déjà exploité par un partenaire | Réemploi possible d’une exploitation existante | Dépendance au partenaire, publics autorisés, partage des données et sortie à contractualiser |

Recommandation : choisir selon la capacité d’exploitation et le mode d’accès réellement utilisable par les candidats. Ne pas exiger un email comme identifiant sans vérifier l’usage ; ne pas imposer des SMS payants sans coût et fiabilité connus. POC avant S2 : connexion/refus/reconnexion, expiration et révocation, JWKS/rotation, mauvais issuer/audience, retour interdit, suppression de contexte réutilisé et absence de jetons dans les traces.

## Backlog de clôture estimable

Les durées ci-dessous concernent le travail humain restant et sont des hypothèses à relire, pas des temps déjà consommés ni une promesse. Une tâche préparée attend sa revue ; les essais ne sont pas déjà réalisés.

| ID | Travail / critère d’achèvement | Place / dépendance | Estimation proposée |
|---|---|---|---|
| S0-01 | Confirmer responsables et disponibilités des cinq places | OUOBA + tous | 0,5 j |
| S0-02 | Relire AUTH/ME, expiration, déconnexion et retour autorisé | D1 / critères fournisseur | 0,5–1 j |
| S0-03 | Relire quinze questions, conseils et critères ; décider corrections | OUOBA + D2 / corpus v2 | 0,5–1 j |
| S0-04 | Relire plan figé, transitions, révisions et doublons | D2 / contrats 0.3 | 0,5 j |
| S0-05 | Relire preuve et résultats invalide/partiel/tardif | D3 / grille et processing | 0,5–1 j |
| S0-06 | Relire douze écrans et aide correspondante dans les deux variantes | D4 / maquettes | 0,5 j |
| S0-07 | Organiser puis mener première boucle d’essais réels | D4 + OUOBA / participants disponibles | 1–2 j |
| S0-08 | Analyser difficultés, attribuer et retester corrections essentielles | D4 + rôle concerné / observations | 1–2 j, à ajuster |
| S0-09 | Relire frontières, données, événements, environnements et risques | D5 / contrats et ADR | 0,5–1 j |
| S0-10 | Relire backlog, capacité et dépendances ; décider réception S0 | Équipe + OUOBA / preuves précédentes | 0,5 j |

Travaux de préparation de ces tâches : réalisés par l’assistant dans ce dossier. Une estimation par l’équipe reste nécessaire pour la condition de réception. Les jours ne se déduisent pas mécaniquement d’une disponibilité de cinq personnes : les relectures, essais et dépendances peuvent être séquentiels.

## Risques attribués

| Risque | Responsable de suivi | Preuve de maîtrise à recevoir |
|---|---|---|
| Questions peu comprises ou déconnectées du premier emploi | OUOBA / D2 / D4 | Avis métier et notes candidats |
| Confusion brouillon, serveur et retour IA | D4 / D2 | Essais T04/T06, correction et nouvel essai |
| Accès au coaching d’un autre compte | D1 / D5 | Matrice relue, puis essais A/B sur code privé en S2/S3 |
| Duplications et résultat tardif après suppression | D2 / D3 / D5 | Contrat relu, puis pannes et contraintes en implémentation |
| Dépenses fournisseur incertaines | OUOBA / D3 / D5 | Budget et registre d’usage qualifiés avant activation |
| Capacité d’équipe et exploitation non confirmées | OUOBA / D5 | Nominations/disponibilités, propriétaire d’exploitation |
| Données privées, sous-traitance et sauvegardes mal définies | OUOBA / D1 / D5 | Politique et notices reçues avant pilote |
