(() => {
  const data = JSON.parse(document.getElementById('review-data').textContent);
  let evidence = data.evidence;
  let dirty = false;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
  const get = path => path.split('.').reduce((item, key) => item?.[key], evidence);
  const set = (path, value) => {
    const keys = path.split('.');
    const last = keys.pop();
    keys.reduce((item, key) => item[key], evidence)[last] = value;
    dirty = true;
  };
  const field = (label, path, type='text') => `<label class="field">${esc(label)}<input data-path="${esc(path)}" type="${type}" value="${esc(get(path))}" ${type==='number'?'min="0" max="10" step="0.5"':''}></label>`;
  const note = (label,path) => `<label class="field full">${esc(label)}<textarea data-path="${esc(path)}">${esc(get(path))}</textarea></label>`;
  const select = (label,path,options) => `<label class="field">${esc(label)}<select data-path="${esc(path)}">${options.map(([key,text])=>`<option value="${esc(key)}" ${get(path)===key?'selected':''}>${esc(text)}</option>`).join('')}</select></label>`;
  const checkbox = (label,path) => `<label class="check"><input type="checkbox" data-path="${esc(path)}" ${get(path)?'checked':''}>${esc(label)}</label>`;
  const verdicts = [['pending','À relire'],['approved','Approuvé après lecture'],['revise','Modifications demandées']];
  const review = (prefix,label) => `<div class="review-fields"><h3>${esc(label)}</h3><div class="grid">${field('Nom ou pseudonyme du relecteur',prefix+'.reviewer')}${field('Date réelle de relecture',prefix+'.reviewed_at','date')}${select('Avis',prefix+'.verdict',verdicts)}${note('Notes, périmètre relu et raisons de l’avis',prefix+'.notes')}</div></div>`;

  function renderCorpus() {
    document.getElementById('corpus').innerHTML = `<h2>Relire les quinze questions</h2><p>Proposition corrigée version 2. Lire chaque question avec son aide et ses critères avant de donner un avis sur le scénario.</p><p class="muted">Deux critères ont été ajustés : une question de démarche ou de lien au poste n’impose plus un nouvel exemple vécu.</p>` + data.corpus.map((s,i) => `<article class="card"><h3>${esc(s.title)}</h3><p>${esc(s.summary)}</p><span class="tag">Version ${s.version} · ${s.question_count} questions · avis métier en attente de saisie</span>${s.questions.map((q,n)=>`<details class="question"><summary>${n+1}. ${esc(q.prompt)}</summary><p class="criterion">Type : ${esc(q.response_kind)} · critères : ${esc(q.criteria.map(k=>s.rubric.find(c=>c.key===k)?.label).join(', '))}</p><ul>${q.guidance.map(t=>`<li>${esc(t)}</li>`).join('')}</ul></details>`).join('')}<details><summary>Grille du scénario</summary>${s.rubric.map(c=>`<p><strong>${esc(c.label)}</strong> : ${esc(c.description)}</p>`).join('')}</details>${review('business_reviews.'+i,'Avis métier sur les cinq questions et la grille')}</article>`).join('');
  }
  function renderTeam() {
    const roles={D1:'Identité, compte, droits',D2:'Catalogue, questions, sessions',D3:'Évaluation, preuves, travaux IA',D4:'Parcours, maquettes, essais UX',D5:'Données, livraison, exploitation'};
    document.getElementById('team').innerHTML=`<h2>Confirmer les personnes et la capacité</h2><p>OUOBA Abdou Rasmané est l’interlocuteur nommé. Renseignez les cinq places sans inventer de développeur ni de disponibilité. Une personne peut tenir plusieurs rôles ; ses jours ne se multiplient pas.</p><div class="grid">${field('Responsable produit','responsible_product')}${field('Responsable relecture métier','responsible_business_review')}${field('Coordination de l’équipe','team_coordinator')}</div>`+Object.entries(roles).map(([key,label])=>`<article class="card"><h3>${key} · ${label}</h3><div class="grid">${field('Nom ou pseudonyme','developers.'+key+'.name')}${field('Jours disponibles sur un sprint de deux semaines','developers.'+key+'.availability_days_per_sprint','number')}</div>${checkbox('La personne a relu et compris son périmètre','developers.'+key+'.scope_acknowledged')}</article>`).join('');
  }
  function renderTests() {
    document.getElementById('tests').innerHTML=`<h2>Consigner des séances réellement réalisées</h2><p>Cible exploratoire proposée : cinq personnes, première boucle de trois. Les codes P01, P02… sont attribués à la séance. Aucun test n’est créé automatiquement.</p><div class="links"><a href="03_PROTOCOLE_ESSAIS.md" target="_blank" rel="noopener">Lire le protocole</a></div><button id="add-session">Ajouter une fiche de séance</button>`+(evidence.participant_sessions.length?'':`<p class="empty">Aucune observation candidate renseignée. La possibilité d’organiser des essais est confirmée ; leurs résultats restent à recueillir.</p>`)+evidence.participant_sessions.map((session,i)=>`<article class="card"><h3>Séance ${i+1}</h3><div class="grid">${field('Code anonyme du participant','participant_sessions.'+i+'.participant_code')}${field('Animateur','participant_sessions.'+i+'.facilitator')}${field('Date réelle de séance','participant_sessions.'+i+'.observed_at','date')}${field('Appareil et contexte utiles','participant_sessions.'+i+'.device')}${select('Objectif du candidat','participant_sessions.'+i+'.objective',[['','À renseigner'],['internship','Premier stage'],['first_job','Premier emploi']])}</div>${checkbox('La personne a accepté cette séance et les notes minimales','participant_sessions.'+i+'.participation_agreed')}${data.tasks.map((task,n)=>`<div class="task"><p>${task.id} · ${esc(task.instruction)}</p><div class="grid">${select('Résultat observé','participant_sessions.'+i+'.tasks.'+n+'.outcome',[['not_run','Non réalisée'],['success','Réussie sans aide'],['assisted','Réussie avec aide'],['failed','Échec observé']])}${note('Observation factuelle et aide éventuellement fournie','participant_sessions.'+i+'.tasks.'+n+'.observation')}</div></div>`).join('')}${note('Bilan de la séance et difficultés à traiter','participant_sessions.'+i+'.summary')}</article>`).join('');
  }
  function renderReview() {
    document.getElementById('review').innerHTML=`<h2>Revoir les décisions et la réception</h2><p>La nomination des responsables n’approuve pas le contenu. Les avis ci-dessous sont à renseigner après lecture et examen des observations.</p><div class="links"><a href="02_PARCOURS_ET_CONTRATS.md" target="_blank" rel="noopener">Parcours et contrats</a><a href="04_RESPONSABLES_DECISIONS_BACKLOG.md" target="_blank" rel="noopener">Décisions et backlog</a><a href="05_RECEPTION.md" target="_blank" rel="noopener">Conditions de réception</a></div>${review('decisions_review','Contrats et décisions de conception')}${review('backlog_review','Backlog, estimations et capacité de l’équipe')}${review('product_review','Avis produit sur la référence S0-0.3 et les essais')}
    <article class="card"><h3>Difficultés et corrections</h3><p>Une absence de note ne signifie pas qu’aucun problème n’a été observé.</p><button id="add-finding">Ajouter une difficulté</button>${evidence.findings.map((f,i)=>`<div class="task"><h3>${esc(f.id)}</h3><div class="grid">${select('Gravité','findings.'+i+'.severity',[['critical','Critique'],['major','Majeure'],['minor','Mineure']])}${select('État','findings.'+i+'.status',[['open','Ouverte'],['resolved','Corrigée et revérifiée'],['accepted','Limite acceptée explicitement']])}${field('Responsable du traitement','findings.'+i+'.owner')}${note('Problème et référence de séance/tâche','findings.'+i+'.description')}${note('Correction, nouvel essai ou justification de la limite','findings.'+i+'.retest_notes')}</div></div>`).join('')}</article><article class="card"><h3>Complétude des saisies</h3><ul id="completeness" class="status-list"></ul><p class="muted">Ce compteur aide à relire les saisies. La décision S0 dépend du registre vérifié et des personnes responsables ; aucun résultat humain n’est inventé.</p></article>`;
    summary();
  }
  function summary() {
    const list=document.getElementById('completeness'); if(!list)return;
    const reviewed=evidence.business_reviews.filter(r=>r.verdict==='approved'&&r.reviewer&&r.reviewed_at&&r.notes).length;
    const people=Object.values(evidence.developers).filter(r=>r.name&&r.availability_days_per_sprint!==null&&r.scope_acknowledged).length;
    const sessions=evidence.participant_sessions.filter(s=>s.observed_at&&s.participation_agreed&&s.tasks.every(t=>t.outcome!=='not_run'&&t.observation.trim())).length;
    list.innerHTML=`<li>${reviewed}/3 avis métier complets déclarés</li><li>${people}/5 places développeurs renseignées</li><li>${sessions} séance(s) avec tâches renseignées</li><li>${evidence.findings.filter(f=>f.severity==='critical'&&f.status!=='resolved').length} difficulté(s) critique(s) non résolue(s) déclarée(s)</li>`;
  }
  function render() {renderCorpus();renderTeam();renderTests();renderReview();}
  document.addEventListener('input',e=>{const path=e.target.dataset.path;if(!path)return;set(path,e.target.type==='checkbox'?e.target.checked:e.target.type==='number'?(e.target.value===''?null:Number(e.target.value)):e.target.value);summary();});
  document.addEventListener('click',e=>{
    const button=e.target.closest('button');if(!button)return;
    if(button.dataset.panel){document.querySelectorAll('.panel').forEach(p=>p.hidden=p.id!==button.dataset.panel);document.querySelectorAll('nav button').forEach(b=>{if(b===button)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});}
    if(button.id==='add-session'){evidence.participant_sessions.push({participant_code:'P'+String(evidence.participant_sessions.length+1).padStart(2,'0'),facilitator:'',observed_at:'',device:'',objective:'',participation_agreed:false,tasks:data.tasks.map(t=>({id:t.id,outcome:'not_run',observation:''})),summary:''});dirty=true;renderTests();}
    if(button.id==='add-finding'){evidence.findings.push({id:'F'+String(evidence.findings.length+1).padStart(2,'0'),severity:'critical',status:'open',owner:'',description:'',retest_notes:''});dirty=true;renderReview();}
    if(button.id==='export'){const blob=new Blob([JSON.stringify(evidence,null,2)+'\n'],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='SimuEmploi_S0_preuves.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);dirty=false;document.getElementById('message').textContent='Export demandé. Conservez le fichier téléchargé ; il ne modifie pas automatiquement le registre du projet.';}
  });
  document.getElementById('import').addEventListener('change',async e=>{
    const file=e.target.files[0];if(!file)return;
    try{const value=JSON.parse(await file.text());if(value.schema_version!=='S0-0.3'||!value.developers||!Array.isArray(value.business_reviews)||value.business_reviews.length!==3||!Array.isArray(value.participant_sessions)||!Array.isArray(value.findings)||!value.product_review||!value.decisions_review||!value.backlog_review)throw new Error('Format de registre incompatible.');
      if(!['D1','D2','D3','D4','D5'].every(k=>value.developers[k]))throw new Error('Affectations incomplètes.');
      if(!value.participant_sessions.every(s=>Array.isArray(s.tasks)&&s.tasks.length===8))throw new Error('Fiches de séance incompatibles.');
      evidence=value;dirty=true;render();document.getElementById('message').textContent='Fichier repris dans cette page ; relisez puis exportez après modification.';
    }catch(error){document.getElementById('message').textContent=error.message;}
  });
  window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
  render();
})();
