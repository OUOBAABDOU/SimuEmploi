# Référence de conception — parcours, contrats et états

S0-0.3, 22 novembre 2026. Spécification technique relue en interne, à recevoir avec le produit. **Les routes privées de ce document ne sont pas implémentées.** `application/contracts/openapi.json` décrit uniquement l’API existante. La version 0.3 précise les ambiguïtés antérieures ; tout écart de mise en œuvre doit être identifié en revue.

## Parcours candidat de référence

Découverte → consultation publique du catalogue → préparation → connexion si création d’une session privée → préférences facultatives → création de session → une question à la fois → réponse confirmée → retour ou continuation autorisée → fin confirmée → rapport. Historique et compte restent accessibles depuis l’espace authentifié. Une préférence changée ne modifie jamais une session commencée.

Référence initiale proposée : **guidée**, à confronter à la variante autonome. La nomination du porteur ne constitue pas encore son choix final. Les sélecteurs d’écran, panne et variante appartiennent à l’atelier, pas à l’application.

| Écran | Entrée / action principale | Cas à couvrir et preuve de recette future | Rôle |
|---|---|---|---|
| C01 Découvrir | Public ; voir catalogue ou connexion | Utilité comprise sans média ; aucune promesse d’embauche | D4 |
| C02 Connexion | Fournisseur OIDC ; retour interne autorisé | Première connexion, refus, indisponibilité, expiration et déconnexion ; pas de champ sans fonction | D1 |
| C03 Objectif | Stage/emploi ; domaine et expérience facultatifs | Ne pas inventer une préférence si ignorée ; erreur près du champ ; confirmation après transaction | D1 |
| C04 Accueil | Préparer / reprendre | Premier historique vide ; reprise prioritaire ; aucune note fictive | D4 |
| C05 Catalogue | Filtre / fiche | Filtre URL conservé, pagination, vide distinct d’une panne, publication contrôlée | D2 |
| C06 Préparation | Commencer | Plan/version/durée indicative ; authentification revient ici ; double clic sans double session | D2 |
| C07 Réponse | Relire et valider | Vide refusé, brouillon local distinct du serveur, coupure/conflict/reconnexion, pause | D2/D4 |
| C08 Retour | Comprendre / continuer | Conservé ≠ évalué ; prêt/partiel/indisponible ; preuve citée réellement présente | D3 |
| C09 Fin | Confirmer la fin | Dernière réponse conservée ; fin distincte du rapport ; doublon sans travail supplémentaire | D2 |
| C10 Historique | Reprendre / consulter | Propriété, pagination, états cohérents ; réponse d’un autre compte refusée | D4 |
| C11 Rapport | Choisir un conseil | Références/versions, limites et partie manquante ; pas de classement | D3/D4 |
| C12 Compte | Préférences / demande / déconnexion | Confirmation et annulation suppression ; statut réel ; nettoyage local sous bonne identité | D1/D5 |

Minimum de conception : largeur 320 px, textes zoomables, actions tactiles 44 px, labels visibles, aide repliable par question, focus après navigation/erreur/dialogue et annonce des statuts. Une image décorative est indépendante du texte et de l’action. Les contrastes, lecteur d’écran et clavier virtuel seront qualifiés sur les composants réels ; les contrôles locaux ne les certifient pas entièrement.

## Contrat d’identité

`GET /auth/login?return_to=...` ouvre un contexte de connexion temporaire, lié à l’origine et à un chemin interne autorisé. `GET /auth/callback` valide code, état, nonce, issuer/audience/signature/expiration et PKCE selon le flux. L’échange et les jetons fournisseur restent serveur. `POST /auth/logout` révoque l’accès et supprime le cookie ; refus CSRF pour une mutation non autorisée.

Utilisateur interne : `id: UUID`, `issuer`, `subject`, `status`. Contrainte unique `(issuer, subject)`, sans fusion automatique par email. Le principal serveur porte l’identité et les droits ; aucun `owner_id` fourni par le client n’est accepté.

`GET /api/v1/me` retourne identité minimale et préférences. `PUT /api/v1/me/preferences` utilise `{objective: internship|first_job|null, domain: beginner|presentation|null, experience: no_paid_work|some_experience|null, locale: fr, expected_revision: integer}`. Réponse : préférences confirmées et nouvelle révision ; 409 si écriture concurrente. Le champ d’expérience est facultatif et sert à l’aide, pas à une note de valeur du candidat.

Cookie d’accès publié Secure/HttpOnly ; `SameSite`, durée, invalidation, politique de reconnexion et CSRF à qualifier avec l’origine/fournisseur avant S2. Un brouillon privé est isolé par compte et session. Déconnexion : fermer accès, nettoyer données locales prévues et ne pas envoyer un brouillon sous une autre identité après reconnexion. Le pilote adulte est l’orientation proposée, à confirmer dans la notice avant ouverture.

## Schémas communs de session

- `Session`: `id`, `state`, `revision >= 1`, `scenario_id`, `scenario_version`, `rubric_version`, `question_plan`, `answers`, `created_at` UTC. Les données renvoyées appartiennent au principal.
- `Answer`: `id`, `question_key`, `answer_revision=1`, `text`, `saved_at` UTC, `evaluation_state`. Une soumission confirmée est immuable dans ce premier lot ; une correction pédagogique se fait dans un nouvel essai. Relire reste une lecture.
- `Error`: `code`, `message`, `correlation_id`, éventuellement `{field, code}` sans recopier la saisie. Révision courante autorisée dans un conflit ; jamais le texte d’un tiers.

Propositions techniques à figer pour les premiers tests de contrat : texte non blanc **1–4 000 caractères Unicode**, 1–10 questions par plan, pagination par défaut 10 et maximum 20. La limite protège la taille du traitement ; elle ne mesure pas une compétence. Les erreurs de validation nomment le champ et la règle sans renvoyer les contenus privés.

## Routes et effets proposés

| Opération | Entrée | Réponse / contraintes |
|---|---|---|
| `POST /api/v1/sessions` | `{scenario_id, scenario_version}`, `Idempotency-Key: UUID` | 201 nouveau / 200 relecture de la même opération ; snapshot publié, propriétaire serveur |
| `GET /api/v1/sessions/{id}` | ID autorisé | 200 ; aucune transition ni création de job par lecture |
| `POST /api/v1/sessions/{id}/answers` | `{question_key, text, expected_revision}`, clé UUID | 201 réponse durable / 200 rejouée ; nouvelle révision, état évaluation et référence autorisée |
| `POST /api/v1/sessions/{id}/pause` | `{expected_revision}`, clé UUID | 200 après transition durable |
| `POST /api/v1/sessions/{id}/resume` | `{expected_revision}`, clé UUID | 200 après reprise explicite, sans création d’une seconde session |
| `POST /api/v1/sessions/{id}/complete` | `{expected_revision}`, clé UUID | 200, fin durable et état de rapport distinct ; toutes les réponses requises présentes |
| `GET /api/v1/sessions` | Filtre état, limite, curseur | 200, historique du propriétaire ; curseur lié au filtre et ordre stable |
| `GET /api/v1/answers/{id}/evaluation` | ID autorisé | 200 avec état/versions/critères/preuves ; attente représentée par état, pas par fausse appréciation |
| `POST /api/v1/answers/{id}/evaluation/retry` | `{input_revision}`, clé UUID | 202 si nouveau travail accepté / 200 si opération connue ; droits et budget recontrôlés |
| `GET /api/v1/sessions/{id}/report` | ID autorisé | 200, statut et version du rapport avec limites ; pas de génération par lecture |
| `POST /api/v1/sessions/{id}/report/retry` | `{report_version}`, clé UUID | 202 accepté / 200 connu ; version publiée jamais écrasée silencieusement |
| `POST /api/v1/feedback` | `{resource_type, resource_id, reason, comment?}`, clé UUID | 201 accusé ; commentaire proposé maximum 1 000 caractères ; ressource possédée |
| `POST /api/v1/data-requests` | `{kind: export|delete, confirmation_token?}`, clé UUID | 202 demandé / 200 connu ; confirmation récente pour suppression selon politique |
| `GET /api/v1/data-requests/{id}` | ID autorisé | 200 état réel, étapes restantes et téléchargement privé limité si prêt |

La réponse sauvegardée utilise **201/200**, même si l’analyse est différée. Les demandes de travail différé utilisent **202/200**. Cela précise l’ancien usage ambigu de 202 pour la sauvegarde ; dans tous les cas, l’accusé suit la transaction durable et n’annonce pas une IA terminée. Les CAT-01/CAT-02 actuels ne changent pas dans cette proposition.

Codes transversaux : 401 accès absent/expiré ; **404 pour ressource privée inexistante ou appartenant à un autre compte**, même message ; 409 état/révision/clé incompatibles ; 422 format/limite ; 429 quota ou fréquence, avec reprise si déterminable ; 503 si l’opération n’a pas été acceptée durablement. Une panne du fournisseur après acceptation apparaît dans l’état d’évaluation, sans annuler la réponse.

## Transitions, révisions et idempotence

```mermaid
stateDiagram-v2
  [*] --> active: création durable
  active --> active: réponse suivante confirmée / révision +1
  active --> paused: pause explicite
  paused --> active: reprise explicite
  active --> completed: toutes les réponses confirmées puis fin
  active --> cancelled: abandon autorisé
  paused --> cancelled: abandon autorisé
  completed --> [*]
  cancelled --> [*]
```

La route d’abandon sera explicitée avant son implémentation ; aucune fermeture de page n’annule une session. Une réponse n’est acceptée que pour la prochaine question du plan et en état actif. Unique `(session_id, question_key)` pour ce premier essai. Les mutations vérifient état et révision dans la transaction. Deux opérations concurrentes différentes ne peuvent valider la même révision ; conflit 409 et rechargement sans écrasement.

Clé idempotente liée au principal, à l’opération, à la ressource et à l’empreinte canonique de la requête. Même clé/empreinte : résultat initial relu sous droits actuels ; même clé/contenu différent : conflit. Rejouer ne crée pas de nouveau job ni de consommation client. Rétention des clés compatible avec reprise, jobs et contraintes métier : proposition minimale 24 h, prolongée tant que l’opération active doit être rejouée, à qualifier avant S3. Expiration et restauration ne dispensent pas des contraintes métier de doublon.

## Retour, preuves et travaux

Résultat d’évaluation : `answer_id`, `input_revision`, versions scénario/grille/prompt, modèle/configuration, `status`, `criteria[]`, limites. Chaque critère possède clé de grille, appréciation qualitative `supported|needs_work|insufficient_evidence`, commentaire et conseil bornés. Ces appréciations ne sont pas un score global. `insufficient_evidence` décrit les éléments disponibles, pas une incapacité personnelle.

Preuve : offsets début/fin dans le texte figé et extrait exact correspondant. La validation contrôle offsets, égalité de l’extrait et critère autorisé. Si la preuve manque, ne pas inventer de citation. Une question hypothétique est évaluée sur la démarche ; un critère absent du plan ne peut être ajouté par le modèle. JSON invalide/clé inconnue/preuve inventée : résultat non prêt et catégorie d’erreur explicite.

États : `queued → processing → ready|partial|unavailable|cancelled`. Une attente n’est pas une preuve de conservation ; celle-ci provient exclusivement de l’accusé de réponse. Un état partiel expose les critères manquants. Rapport : liste exacte des réponses et évaluations citées, versions, statut et limites ; une nouvelle évaluation n’écrase pas un rapport publié.

Événement technique : `event_id`, `type`, `schema_version`, `job_id`, `resource_id`, `input_revision`, `correlation_id`. Pas de réponse brute, CV, média ou jeton dans le broker. Transaction locale : réponse + réservation éventuelle + job + outbox. En S3 sans évaluation activée, la réponse reste indépendante d’un worker.

Le dispatcher vérifie confirmation/routage ; panne après publication peut produire un doublon. Le worker revendique avec token/échéance, recharge données et droits, appelle le fournisseur hors transaction longue puis publie sous token courant. Une échéance dépassée ou une suppression invalide un ancien résultat. Une session terminée n’invalide pas automatiquement une évaluation portant sur une réponse toujours autorisée. La révision d’une autre question n’invalide pas cette réponse. L’exécution fournisseur après timeout est incertaine : mesurer coût par tentative, éviter une nouvelle consommation client et rapprocher avant relance.

## Droits et conservation

Catalogue visible : lecture publique. Compte/préférences/session/réponse/évaluation/rapport/demande : propriétaire uniquement. Autre candidat : refus serveur sur lecture et mutation, même si l’URL est connue. Administration : aucun accès ordinaire au contenu de coaching ; intervention exceptionnelle autorisée, bornée et journalisée. D1/D5 testent A/B, reconnexion, caches, suppression et résultat tardif.

Suppression : état `requested → processing → completed|needs_action|failed`, révocation et invalidation des travaux prévues. Ne pas annoncer « supprimé » avant confirmation des étapes couvertes par la politique. Sauvegardes, délais, bases légales, résidence et sous-traitants doivent être documentés par le responsable données avant pilote. Ce dossier ne fixe pas arbitrairement une durée légale.
