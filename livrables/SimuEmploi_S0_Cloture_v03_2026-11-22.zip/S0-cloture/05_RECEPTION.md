# Réception S0 — preuves et décision

Référence S0-0.3, 22 novembre 2026. La préparation du dossier et la décision de réception sont deux états explicites. L’instruction du porteur impose d’attendre la réception de S0 avant de poursuivre les autres sprints.

| Condition | Preuve attendue | Situation connue |
|---|---|---|
| Responsable produit / métier nommé | Nomination reçue | **OUOBA Abdou Rasmané**, réponse dans ce chat |
| Premier corpus relu par responsable métier | Trois avis portant chacun sur cinq questions et la grille, date et version | En attente |
| Maquettes et parcours compris par candidats | Séances réelles, notes des huit tâches, difficultés et corrections | Possibilité d’organiser reçue ; aucun résultat reçu |
| Affectation D1–D5 et capacité réelle | Noms ou pseudonymes, jours disponibles, périmètre compris | Ouoba, Abdou, Rasmané, limata, Oumou affectés dans cet ordre ; disponibilités et compréhension à confirmer |
| Contrats/décisions relus | Avis responsable, choix et conditions restant à fermer avant chaque lot | Référence technique complétée ; avis humain en attente |
| Backlog estimé par équipe | Relecture, estimation ajustée à capacité et dépendances | Découpage préparé ; confirmation équipe en attente |
| Référence produit reçue | Avis produit daté sur S0-0.3, avec variante et notes d’essais | Modifications demandées par OUOBA Abdou Rasmané ; détails à préciser, réception non accordée |
| Difficultés critiques résolues | Observation, responsable, correction et nouvel essai | Registre vierge ; absence d’observation ne signifie pas absence de difficulté |

`preuves-humaines.json` contient des champs vides pour ces preuves. `verifier_s0.py` produit `etat-reception.json` et retourne un code non nul si la réception reste incomplète. Le bouton d’export de l’atelier ne publie aucune validation et n’envoie aucun message.

Les tests automatisés des maquettes portent sur des écrans et transitions simulés. Ils sont consignés séparément ; ils ne sont jamais comptés comme séances candidates. Le contrôle de réception détecte champs manquants, avis incomplets et problèmes critiques ouverts. Il ne peut pas prouver à lui seul qu’un déclarant était présent : le responsable produit conserve le contexte de séance.

Après réception : consigner auteur/date/version et décision dans le journal S0. Une modification majeure de corpus, parcours ou contrat rouvre la relecture concernée. Les signatures peuvent être remplacées par une approbation explicite dans ce chat, si son périmètre est précis ; « nous pouvons organiser les tests » n’approuve pas leur résultat.
