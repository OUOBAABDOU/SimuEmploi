# Vérifications de préparation S0-0.4

22 novembre 2026, Windows, Playwright 1.62.1 et Chrome 157.0.8103.40. Les résultats concernent les livrables de conception et le contrôle de réception, pas une nouvelle fonctionnalité de S1.

## Résultats

- **102 contrôles techniques réussis** : 96 combinaisons des douze écrans candidat, deux variantes et quatre largeurs (320, 360, 736, 1024 px), plus six contrôles groupés d’interactions, de médias et d’atelier.
- Catalogue adapté aux trois exercices ; réponse non vide brève acceptée, aide correspondant à la question, brouillon de démonstration conservé pendant coupure/pause/reprise.
- Relance liée au contexte précédent ; deux réponses différentes produisent deux relances différentes. La démonstration se termine dans la limite de tours. La progression ne présente plus un nombre fixe de cinq questions.
- Question suivante en préparation ou indisponible : aucune nouvelle question imposée, réessai normal possible, réponse précédente utilisée lors de la reprise.
- Question adaptative bornée à 700 caractères et affichage à 360 px sans débordement. Le contexte complet du tour précédent est consultable séparément, sans citations imbriquées dans la nouvelle question.
- Atelier vérifié dans ses quatre sections à 320, 360 et 1024 px, avec dix tâches par fiche. Les nouvelles fiches ne préremplissent ni accord, ni date, ni succès de tâche ; l’export et la reprise JSON fonctionnent. Les cinq disponibilités de 24 h sont vérifiées dans l’export.
- Référence audio/vidéo : ouverture des deux variantes de préparation vérifiée. Les 96 combinaisons ci-dessus portent sur le candidat texte ; elles ne sont pas une nouvelle recette intégrale des médias. La recette médias antérieure reste dans le dossier candidat.
- Aucune erreur JavaScript non traitée et aucune requête HTTP externe pendant ces contrôles par fichiers locaux.
- **7 tests réussis du contrôle de réception** : nomination seule insuffisante, séance vierge non comptée, codes dupliqués non traités comme trois personnes, relecteur vide/null refusé et difficulté critique non résolue bloquant la réception.
- Ruff conforme avec la configuration `backend/pyproject.toml`. Validation Pydantic des trois banques, critères hypothétiques et politique adaptative effectuée par `verifier_s0.py`.
- Atelier local servi à `127.0.0.1:5174`, réponse HTTP 200 vérifiée. `run-s0.ps1` permet de le relancer.

Résultats détaillés : `verification-maquettes.json`, `verification-preparation.json` et `etat-reception.json`. Les captures de l’atelier et de la question adaptative mobile ont été inspectées. Le scénario mobile a été simplifié après inspection visuelle, puis la recette a été rejouée. Le résultat de recette est marqué en cours puis réussi/échoué : un échec ne conserve pas un ancien succès dans le même fichier.

## Ce que ces résultats ne prouvent pas

Les maquettes simulent les effets et perdent leur mémoire à l’actualisation. Aucun backend privé, capture média ou fournisseur IA n’est actif dans cette référence. La génération locale sert à rendre les branches visibles ; sa règle de brièveté n’est pas une validation pédagogique d’un modèle. Le registre A/B/C décrit des fournisseurs fictifs désactivés et non qualifiés. Les tests n’observent aucun candidat réel, ne représentent pas le Burkina Faso et ne certifient pas l’accessibilité complète ni un téléphone physique.

Les copies audio/vidéo conservent des tours préécrits pour illustrer capture et relecture ; une notice explicite qu’ils ne définissent pas le futur déroulement adaptatif à partir de transcriptions confirmées. L’ouverture de ces copies ne constitue pas une nouvelle recette intégrale des médias.

Le registre humain reste distinct des fixtures synthétiques de tests. Les téléchargements créés pendant les tests n’ont pas remplacé `preuves-humaines.json`. Le contrôle de complétude ne peut pas authentifier une séance ou une signature ; les notes et avis doivent venir des responsables réels.

Les avis sur S0-0.3 sont conservés dans l’historique avec leur version de corpus 2 ; les avis courants concernent la banque version 3 / S0-0.4. Les nominations D1–D5 et les 24 h chacun sont reçues. Compréhension des périmètres et estimations à confirmer. Trois avis métier sur les banques/politique, avis contrats, avis backlog et décision produit restent à recevoir. **Zéro séance réelle exploitable enregistrée** ; le protocole propose une première boucle de trois, cible cinq.

La préparation matérielle S0-0.4 est complète et vérifiée. **S0 n’est pas reçu** : les relectures et essais humains restent nécessaires avant toute poursuite des autres sprints selon la consigne du porteur. Le travail humain S0 restant est estimé à 59 h dans une proposition à confirmer, sous capacité de 120 h ; ce n’est ni une consommation d’heures ni une garantie de clôture à date.
