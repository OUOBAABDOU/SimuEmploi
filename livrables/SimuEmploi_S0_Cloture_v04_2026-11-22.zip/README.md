# S0 — Dossier de clôture à valider

Référence **S0-0.4**, 22 novembre 2026. Le porteur demande de terminer S0 avant de poursuivre les autres sprints. La première tranche S1 déjà réalisée reste conservée ; aucun nouveau développement S1/S2 n’est engagé dans ce dossier.

**Responsable produit, relecture métier et coordination : OUOBA Abdou Rasmané**, nommé dans ce chat. Le porteur indique pouvoir organiser des essais candidats ; aucun participant ni résultat d’essai n’a encore été transmis. Affectation selon l’ordre de la liste reçue : **D1 Ouoba, D2 Abdou, D3 Rasmané, D4 limata, D5 Oumou**. Disponibilité confirmée : 24 heures chacun par sprint de deux semaines. La compréhension des périmètres adaptés reste à confirmer.

**Modifications reçues et intégrées à la proposition S0-0.4 :** entretien adaptatif et plusieurs API/IA pour le projet. La nouvelle référence reste à approuver ; l’avis sur S0-0.3 est conservé dans l’historique.

## Utiliser ce dossier

1. Ouvrir `atelier.html`, ou lancer `application/run-s0.ps1` puis consulter <http://127.0.0.1:5174/atelier.html>. Il fonctionne localement, sans compte ni transmission. Les données saisies sont conservées seulement dans la page jusqu’à l’export ; télécharger le fichier avant de fermer.
2. Relire le corpus corrigé et les maquettes candidat. Les références audio/vidéo restent des extensions de conception, sans engagement de développement.
3. Confirmer la compréhension des périmètres D1–D5 et les estimations en heures ; les noms et les 24 h sont déjà enregistrés. Réaliser les essais selon `03_PROTOCOLE_ESSAIS.md`, puis reporter les observations réelles.
4. Relire les contrats, décisions et backlog ; exporter les preuves. Remplacer `preuves-humaines.json` uniquement avec une version effectivement renseignée, en conservant la précédente si nécessaire.
5. Exécuter `backend/.venv/Scripts/python.exe tools/verifier_s0.py` depuis `application/`. Le contrôle distingue préparation matérielle et réception humaine ; une maquette automatisée ne valide pas un candidat réel.

## Livrables

| Livrable | Usage |
|---|---|
| `01_RELECTURE_METIER.md` et `corpus-relecture.json` | Trois banques / quinze questions de référence ; politique adaptative à relire |
| `02_PARCOURS_ET_CONTRATS.md` | Douze écrans, erreurs, états, révisions, droits, preuve et contrats détaillés |
| `03_PROTOCOLE_ESSAIS.md` | Instructions d’animation, tâches, observations et décision après essais |
| `04_RESPONSABLES_DECISIONS_BACKLOG.md` | Rôles, dépendances, comparaison OIDC, paramètres proposés et tâches S0 |
| `05_RECEPTION.md` | Conditions de réception et preuves à fournir |
| `maquettes/candidat.html` | Référence cliquable guidée/autonome, adaptée au premier stage/emploi |
| `maquettes/medias.html` | Référence cliquable audio/vidéo, sans capture réelle |
| `atelier.html` | Saisie locale des avis, essais, affectations et observations |
| `preuves-humaines.json` | Nominations, 24 h par personne et avis historisés ; nouvelles validations encore à renseigner |
| `07_ENTRETIEN_ADAPTATIF_ET_MULTI_IA.md` | Architecture et contrats de génération / plusieurs fournisseurs |
| `08_IMPACTS_ET_CAPACITE.md` | Capacité de 120 h et dépendances des lots à réestimer |
| `question-candidate.schema.json`, `ai-registry.example.json` | Schéma de proposition et exemple de registre désactivé |

Les contrats et maquettes S0-0.4 sont une référence à relire, pas une API privée installée. Le corpus version 3 est une banque et une politique d’entretien adaptatif ; le catalogue applicatif version 1 reste inchangé jusqu’à validation métier. Les documents antérieurs sont conservés pour comparaison.

## Commandes de vérification

Depuis `application/backend/` :

```powershell
.\.venv\Scripts\python.exe ../tools/verifier_s0.py
.\.venv\Scripts\python.exe -m pytest ../tools/tests/test_s0_reception.py -q
```

Pour vérifier un export placé ailleurs, ajouter `--evidence 'chemin/SimuEmploi_S0_preuves.json'`. Le contrôle lit cet export et produit le compte rendu ; il ne modifie pas ses avis ni ses observations. Les tests utilisent des fixtures explicitement synthétiques, séparées du registre humain.

## État de réception

La préparation technique est vérifiée dans `verification-preparation.json` et les maquettes dans `verification-maquettes.json` après exécution des contrôles. Les derniers résultats humains figurent dans `etat-reception.json`.

Les cases humaines ne sont pas précochées. Une nomination ne vaut pas approbation des quinze questions ; la possibilité d’organiser des essais ne vaut pas réalisation. Le vérificateur vérifie la complétude des déclarations, pas l’authenticité d’une signature : conserver les notes de séance et le contexte de relecture sans données personnelles inutiles.
